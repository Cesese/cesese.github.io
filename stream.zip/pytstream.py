import streamlink
from sys import argv

try:
	script, first, second = argv
except:
	print("Wrong arguments :\npython pytstream.py <channel name> <quality>\n")
	exit(1)

try:
	streams = streamlink.streams(first)
	#print(str(streams))
	print(str(streams[second])[12:-3])
except:
	exit(1)
