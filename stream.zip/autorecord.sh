#!/bin/zsh -f

if [[ $# -eq 0 ]]; then
	streamer="aypierre"
	quality="480p"
elif [[ $# -eq 2 ]]; then
	streamer=$1
	quality=$2
else
	echo -e "Usage:\n$0 <streamer> <quality>"
	exit 1
fi

if [[ ! -d "$HOME/Videos/youtube-dl/$streamer" ]]; then
	mkdir $HOME/Videos/youtube-dl/$streamer
fi

wait=1
[[ -t 0 ]] && stty -echo
while [[ true ]]; do
	# if streamer is streaming : record it
	#/home/alex/Videos/twitch/create_stream_file.sh $streamer 480p /home/alex/tmp/.$streamer.link && /bin/echo "$(date +\%H:\%M) - $streamer is streaming! Now recording..." && /home/alex/Videos/twitch/recording.sh /home/alex/tmp/.$streamer.link.$quality /home/alex/Videos/youtube-dl/$streamer/$(date +%Y%m%d-stream) && /bin/echo "$(date +\%H:\%M) - ...$streamer is done streaming." && rm /home/alex/tmp/.$streamer.link.$quality && wait=1
	$HOME/Videos/twitch/create_stream_file.sh $streamer 480p $HOME/tmp/.$streamer.link && dialog --title "$streamer is streaming" --infobox "$(date +\%H:\%M) - $streamer is streaming! Now recording..." 0 0 && $HOME/Videos/twitch/recording.sh /home/alex/tmp/.$streamer.link.$quality $HOME/Videos/youtube-dl/$streamer/$(date +%Y%m%d-stream-%Hh%Mm%Ss) && rm $HOME/tmp/.$streamer.link.$quality && wait=1
	# else : wait 5m before trying again
	dialog --title "$streamer is not streaming" --infobox "$(date +"%H:%M - now waiting $wait minutes before retrying")" 0 0
	sleep "$wait"m | pv -t
	if [[ "$wait" -lt "15" ]]; then
		wait=$(($wait + 1))
	fi
done

[[ -t 0 ]] && stty sane
