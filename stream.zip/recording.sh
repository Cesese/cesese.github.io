if [ ! $# -eq 2 ]
then
  echo -e "Usage:\n$0 <stream> <filename>"
  exit 1
fi

video=$1
out=$2

if [ -f "$out.mkv" ]; then
  suffix=0
  while [ -f "$out$suffix.mkv" ]; do
		suffix=$(($suffix+1))
  done
  out=$out$suffix
fi

vlc -q $video --sout=file/ts:$out.mkv
exit 0
