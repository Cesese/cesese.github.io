if [ ! $# -ge 2 ]
then
  echo -e "Usage:\n$0 <twitch channel> <quality> [filename]"
  exit 1
fi
stream=$1
quality=$2
filename=$3
: "${filename:=$stream}"
if [[ "$stream" != http* ]]; then
  stream="twitch.tv/$stream"
fi
#echo -e "channel : $stream\nquality : $quality\nfilename : $filename.$quality"
HERE="/home/alex/Videos/twitch"
command=$(python $HERE/pytstream.py $stream $quality)
if [[ "$command" != "" ]]
then
  echo "$command" > $filename.$quality
  exit 0
else
  exit 1
fi
